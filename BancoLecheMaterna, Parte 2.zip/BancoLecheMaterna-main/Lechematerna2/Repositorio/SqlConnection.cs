﻿namespace Repositorio
{
    internal class SqlConnection : IDisposable
    {
    }
}