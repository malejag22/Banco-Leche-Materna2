﻿

using ENTIDADES;

namespace Repositorio
{
    //public interface IDatosMadreRepositorio
    //{
    //    void IngresarDatosMadre(Madre DatosMadre);
    //}
}

